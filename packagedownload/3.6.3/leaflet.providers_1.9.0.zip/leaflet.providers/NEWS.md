# leaflet.providers 1.9.0 
 * Updated leaflet.providers data on 2019-11-06 from https://unpkg.com/leaflet-providers using version 1.9.0 of leaflet.js 
 
 # leaflet.providers 1.8.0

* Added a `NEWS.md` file to track changes to the package.
* Initialized package (version number 1.8.0 matches version number of leaflet-providers.js).