library(shinytest)
expect_pass(testApp("../", suffix = osName()))
